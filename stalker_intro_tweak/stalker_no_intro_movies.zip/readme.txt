S.T.A.L.K.E.R. Shadow of Chernobyl - Remove Intro Videos
======================================================================================
Disables intro videos but plays the opening cutscene (even with new save files)

INSTALL INSTRUCTIONS
--------------------------------------------------------------------------------------
The archive contains 2 main folders (install only one of them)

"Vanilla" is for users without a modified "config\ui\ui_movies.xml" file
"ZRP-107" is for users with the Zone Reclamation Project installed (v1.07 R5 RC)

1. Open the "Vanilla" or "ZRP-107" folder
2. Copy the gamedata folder *directly* to your STALKER install folder
3. Confirm folder merges if it asks you for confirmation

If it asks if you want to overwrite "ui_movies.xml" then use discretion (see below)

ADDITIONAL INFORMATION ABOUT FILE CONFLICTS
--------------------------------------------------------------------------------------
This means another mod already modifies that file. The Zone Relclamation Project comes with an edited version of it so you will definitely see that with ZRP installed. If you're confident that you haven't installed any other mods that edit "ui_movies.xml" then you can safely overwrite it

If you're unsure then you can check your installed mod archives to see which one modifies the movie data. You can also manually edit the XML file to remove the entries and add a blank video

Raw source files are provided on GitHub: 
https://github.com/ATeaDaze/ateadaze.github.io/tree/main/stalker_intro_tweak
