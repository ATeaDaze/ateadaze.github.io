**TODO**
[ ] Clean up code with jQuery

**BUGS**
[ ] Test evaluation for double blackjack
[ ] Handle Blackjack vs regular 21 (Blackjack wins over 21)
[ ] 

**GENERAL STRUCTURE**
[x] Generate 52 card deck
[x] Deal 2 cards to player
  [x] Verify card is not in-use

[x] Deal 1 card to dealer
  [x] Verify card is not in-use

[x] Evaluate

[x] Stand
  [x] Stop dealing cards to player
  [x] Dealer draws 2nd card
  [x] Dealer draw until they hit 17
  [x] Evaluate

[x] Hit
  [x] Deal 1 card to player
  [x] Evaluate

[x] Evaluate
  [x] Check for win conditions
  [ ] Handle ties
  [ ] Handle Blackjack vs regular 21

**Function Outline**

# Main function
mainGameLoop();
# Reset scores, game board, and bet modifiers, enable player buttons
restartGame();
# Draw a card for the player
drawPlayerCard();
# Draw a card for the dealer
drawDealerCard();
# Draw 1 card and then stand
doubleDown();
# Stop drawing cards for player
stand();
# Check for win conditions
checkForWins();
# Check final score (combine with checkForWins?)
checkFinalScore();
# Update values on score board
updateScore();
# Update cards on game board
updateCards();
# Clear values on score board
clearScoreboard();
# End round, check scores, disable player buttons
endCurrentRound();
# Check for keystrokes: H, S, N, D
getKeyboardInput();
# Cleans whitespace and suit symbol from card for calculations
cleanCardString();
# Gets numerical value of current card (2:10=value, J,K,Q=10, A=11|1)
getCardValue();
# Draw random card that is not in-play
findUniqueCard();
# Generate 52 card deck: (4 suits * 13 ranks = 52)
generateCardDeck();
# Display toast notification when deck is shuffled
displayShuffleToast();
# Reload the page with confirmation prompt
reloadPage();


**Color List**
red:              #ff0000
pale red:         #ff3232

indianred:        #cd5c5c
pale indianred:   #f26d6d


chartreuse:   
pale chartreuse:   #afff60







**TODO LIST (OLD)**
[x] Hide value of 2nd card: not needed as dealer only shows 1 card until player is done

























# Generate 2 hands
  - Dealer
  - Player

# 52 card deck
*Spade* 2 to 10, J, Q, K, A
s2, s3 ... sJ, sQ, sK, sA

*Heart* 2 to 10, J, Q, K, A
h2, h3 ... hJ, hQ, hK, hA

*Club* 2 to 10, J, Q, K, A

*Diamond* 2 to 10, J, Q, K, A

string cardSuit = "JQKA"

function buildDeck() {

for(i = 2; i++; i <= 10)
  Console.log(i);  
  }

}